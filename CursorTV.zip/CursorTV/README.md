# Cursor TV

App para Android TV (Android 12) que cambia el tamaño, forma y color del cursor del mouse.

## Compilar el APK
1. Abre la carpeta en Android Studio (Hedgehog o más nuevo) y espera la sincronización de Gradle.
2. Build > Build APK(s). El archivo queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Instalar en la TV
    adb connect IP_DE_TU_TV:5555
    adb install app-debug.apk

## Usar
1. Abre Cursor TV y pulsa "Abrir ajustes de accesibilidad"; activa Cursor TV.
2. Vuelve a la app: ajusta tamaño, forma y color con el control remoto (se ve en la vista previa).
3. Opcional (puntero grande nativo):
       adb shell pm grant com.example.cursortv android.permission.WRITE_SECURE_SETTINGS

## Mouse con el servicio activo
- Clic izquierdo = toque (mantener = pulsación larga, arrastrar = deslizar)
- Clic derecho = Atrás, clic central = Inicio
- Rueda = desplazamiento vertical
Para volver al cursor normal, desactiva el servicio en Accesibilidad.
