package com.example.cursortv

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.PointerIcon
import android.view.WindowManager
import android.view.WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
import android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
import android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
import android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
import android.view.WindowManager.LayoutParams.MATCH_PARENT
import android.view.WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
import android.view.accessibility.AccessibilityEvent

/**
 * Dibuja un cursor propio sobre toda la pantalla (oculta el del sistema) y
 * reenvía clics, arrastres y rueda del mouse como gestos de accesibilidad.
 * Estados: 0 apuntar, 1 seleccionar (botón presionado), 2 arrastrar, 3 carga (tras el clic).
 */
class CursorService : AccessibilityService(), SharedPreferences.OnSharedPreferenceChangeListener {

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var view: CursorView? = null
    private val main = Handler(Looper.getMainLooper())

    private var busy = false
    private val failsafe = Runnable { if (busy) done() }
    private var pressed = false
    private var moved = false
    private var downX = 0f
    private var downY = 0f
    private var downT = 0L
    private var downButtons = 0
    private val toNormal = Runnable { if (!pressed) view?.setCursorState(0) }

    override fun onServiceConnected() {
        super.onServiceConnected()
        if (view != null) return

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        lp = WindowManager.LayoutParams(
            MATCH_PARENT, MATCH_PARENT, TYPE_ACCESSIBILITY_OVERLAY,
            FLAG_NOT_FOCUSABLE or FLAG_LAYOUT_IN_SCREEN or FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )

        val v = CursorView(this)
        v.pointerIcon = hiddenIcon() // oculta el cursor del sistema
        Prefs.applyTo(this, v)

        v.setOnHoverListener { _, e ->
            v.moveTo(e.x, e.y)
            true
        }

        v.setOnTouchListener { _, e ->
            v.moveTo(e.x, e.y)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.x; downY = e.y
                    downT = e.eventTime
                    downButtons = e.buttonState
                    pressed = true
                    moved = false
                    main.removeCallbacks(toNormal)
                    v.setCursorState(1)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!moved && Math.hypot((e.x - downX).toDouble(), (e.y - downY).toDouble()) > 24) {
                        moved = true
                        v.setCursorState(2)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    pressed = false
                    onRelease(e)
                }
                MotionEvent.ACTION_CANCEL -> {
                    pressed = false
                    v.setCursorState(0)
                }
            }
            true
        }

        v.setOnGenericMotionListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_SCROLL) {
                val s = e.getAxisValue(MotionEvent.AXIS_VSCROLL)
                val endY = (e.y + s * 250f).coerceIn(0f, v.height.toFloat())
                gesture(e.x, e.y, e.x, endY, 150)
                true
            } else false
        }

        wm.addView(v, lp)
        view = v
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(this)
    }

    private fun onRelease(e: MotionEvent) {
        val dur = e.eventTime - downT
        when {
            downButtons and MotionEvent.BUTTON_SECONDARY != 0 -> {
                view?.setCursorState(0)
                performGlobalAction(GLOBAL_ACTION_BACK)
            }
            downButtons and MotionEvent.BUTTON_TERTIARY != 0 -> {
                view?.setCursorState(0)
                performGlobalAction(GLOBAL_ACTION_HOME)
            }
            else -> {
                val d = if (moved) dur.coerceIn(100, 2000) else if (dur >= 500) dur.coerceAtMost(2000) else 50
                view?.setCursorState(3)           // "carga" un momento tras el clic
                main.removeCallbacks(toNormal)
                main.postDelayed(toNormal, 600)
                gesture(downX, downY, e.x, e.y, d)
            }
        }
    }

    /** Inyecta un toque/arrastre. El overlay se vuelve "no tocable" un instante para no interceptarlo. */
    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long) {
        if (busy) return
        val path = Path().apply {
            moveTo(x1, y1)
            if (x1 != x2 || y1 != y2) lineTo(x2, y2)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, dur.coerceAtLeast(1)))
            .build()
        busy = true
        setTouchable(false)
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) = done()
            override fun onCancelled(d: GestureDescription?) = done()
        }, main)
        if (!ok) done() else main.postDelayed(failsafe, dur + 400)
    }

    private fun hiddenIcon() = PointerIcon.getSystemIcon(this, PointerIcon.TYPE_NULL)

    private fun done() {
        main.removeCallbacks(failsafe)
        busy = false
        setTouchable(true)
        // Al volver a ser tocable, obliga al sistema a ocultar de nuevo su cursor
        main.postDelayed({ view?.pointerIcon = hiddenIcon() }, 40)
        main.postDelayed({ view?.pointerIcon = hiddenIcon() }, 200)
    }

    private fun setTouchable(t: Boolean) {
        lp.flags = if (t) lp.flags and FLAG_NOT_TOUCHABLE.inv() else lp.flags or FLAG_NOT_TOUCHABLE
        view?.let { try { wm.updateViewLayout(it, lp) } catch (_: Exception) {} }
    }

    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
        view?.let { Prefs.applyTo(this, it) }
    }

    private fun cleanup() {
        main.removeCallbacksAndMessages(null)
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(this)
        view?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        view = null
    }

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
