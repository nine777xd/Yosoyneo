package com.example.cursortv

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

/** Galería sencilla (navegable con el control remoto) para elegir la imagen de un estado del cursor. */
class ImagePickerActivity : Activity() {

    private var state = 0
    private val uris = ArrayList<Uri>()
    private val pool = Executors.newFixedThreadPool(2)
    private val cache = LruCache<Uri, Bitmap>(80)
    private lateinit var grid: GridView
    private lateinit var empty: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        state = intent.getIntExtra("state", 0)

        val root = FrameLayout(this)
        grid = GridView(this).apply {
            numColumns = 5
            horizontalSpacing = dp(8)
            verticalSpacing = dp(8)
            setPadding(dp(32), dp(32), dp(32), dp(32))
            clipToPadding = false
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
        }
        empty = TextView(this).apply {
            textSize = 20f
            gravity = Gravity.CENTER
            setPadding(dp(64), dp(64), dp(64), dp(64))
            text = "Buscando imágenes…"
        }
        root.addView(grid)
        root.addView(empty)
        grid.emptyView = empty
        setContentView(root)
        title = "Elegir imagen: " + Prefs.states[state]

        if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            load()
        } else {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 1)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) {
            load()
        } else {
            Toast.makeText(this, "Sin permiso para ver tus imágenes", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun load() {
        val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        try {
            contentResolver.query(
                base, arrayOf(MediaStore.Images.Media._ID), null, null,
                MediaStore.Images.Media.DATE_ADDED + " DESC"
            )?.use { c ->
                val idx = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                while (c.moveToNext() && uris.size < 300) {
                    uris.add(ContentUris.withAppendedId(base, c.getLong(idx)))
                }
            }
        } catch (e: Exception) {
            // se mostrará el mensaje de lista vacía
        }
        empty.text = "No se encontraron imágenes.\n\nPasa tus PNG (mejor con fondo transparente) a la TV, " +
            "por ejemplo con Send Files to TV, y vuelve a abrir esta pantalla."
        grid.adapter = Adapter()
        grid.setOnItemClickListener { _, _, pos, _ -> choose(uris[pos]) }
    }

    private fun decode(u: Uri, max: Int): Bitmap? {
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
            var sample = 1
            while (o.outWidth / sample > max * 2 || o.outHeight / sample > max * 2) sample *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
                ?: return null
            val k = max.toFloat() / maxOf(bmp.width, bmp.height)
            return if (k < 1f) {
                Bitmap.createScaledBitmap(
                    bmp,
                    (bmp.width * k).toInt().coerceAtLeast(1),
                    (bmp.height * k).toInt().coerceAtLeast(1),
                    true
                )
            } else bmp
        } catch (e: Exception) {
            return null
        }
    }

    private fun choose(u: Uri) {
        pool.execute {
            val bmp = decode(u, 256)
            runOnUiThread {
                if (bmp == null) {
                    Toast.makeText(this, "No se pudo leer esa imagen", Toast.LENGTH_LONG).show()
                } else {
                    Prefs.saveImage(this, state, bmp)
                    Toast.makeText(this, "Imagen guardada", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }
    }

    override fun onDestroy() {
        pool.shutdownNow()
        super.onDestroy()
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = uris.size
        override fun getItem(p: Int) = uris[p]
        override fun getItemId(p: Int) = p.toLong()

        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val iv = (cv as? ImageView) ?: ImageView(this@ImagePickerActivity).apply {
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(110))
                setBackgroundColor(0xFF37474F.toInt())
            }
            val u = uris[p]
            iv.tag = u
            val cached = cache.get(u)
            if (cached != null) {
                iv.setImageBitmap(cached)
            } else {
                iv.setImageDrawable(null)
                pool.execute {
                    val bmp = decode(u, 160)
                    if (bmp != null) {
                        cache.put(u, bmp)
                        runOnUiThread { if (iv.tag == u) iv.setImageBitmap(bmp) }
                    }
                }
            }
            return iv
        }
    }
}
