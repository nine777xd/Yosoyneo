package com.example.cursortv

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val LARGE = "accessibility_large_pointer_icon"

    private lateinit var preview: CursorView
    private lateinit var status: TextView
    private lateinit var tvSize: TextView
    private lateinit var btnStyle: Button
    private lateinit var btnColor: Button
    private lateinit var btnLarge: Button
    private lateinit var btnHot: Button

    private val rowViews = ArrayList<CursorView>()
    private val rowButtons = ArrayList<Button>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        preview = findViewById(R.id.preview)
        preview.centered = true
        status = findViewById(R.id.status)
        tvSize = findViewById(R.id.tvSize)
        btnStyle = findViewById(R.id.btnStyle)
        btnColor = findViewById(R.id.btnColor)
        btnLarge = findViewById(R.id.btnLarge)
        btnHot = findViewById(R.id.btnHot)

        findViewById<Button>(R.id.btnService).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } catch (e: Exception) {
                Toast.makeText(this, "Abre Ajustes > Accesibilidad y activa Cursor TV", Toast.LENGTH_LONG).show()
            }
        }

        val seek = findViewById<SeekBar>(R.id.seekSize)
        seek.progress = Prefs.size(this) - Prefs.MIN
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    Prefs.setSize(this@MainActivity, p + Prefs.MIN)
                    refresh()
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        btnStyle.setOnClickListener {
            Prefs.setStyle(this, (Prefs.style(this) + 1) % Prefs.styles.size); refresh()
        }
        btnColor.setOnClickListener {
            Prefs.setColor(this, (Prefs.color(this) + 1) % Prefs.colors.size); refresh()
        }
        btnLarge.setOnClickListener { toggleLarge() }
        btnHot.setOnClickListener {
            Prefs.setHotCenter(this, !Prefs.hotCenter(this)); refresh()
        }

        buildImageRows()
    }

    private fun buildImageRows() {
        val box = findViewById<LinearLayout>(R.id.imgContainer)
        for (i in Prefs.states.indices) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val pv = CursorView(this).apply {
                centered = true
                strictImage = true
                capPx = dp(64).toFloat()
                setCursorState(i)
                setBackgroundColor(0xFF455A64.toInt())
            }
            row.addView(pv, LinearLayout.LayoutParams(dp(72), dp(72)))

            val pick = Button(this).apply {
                setOnClickListener {
                    startActivity(Intent(this@MainActivity, ImagePickerActivity::class.java).putExtra("state", i))
                }
            }
            row.addView(pick, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val clear = Button(this).apply {
                text = "Quitar"
                setOnClickListener { Prefs.clearImage(this@MainActivity, i); refresh() }
            }
            row.addView(clear)

            box.addView(row)
            rowViews.add(pv)
            rowButtons.add(pick)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun largeOn() = Settings.Secure.getInt(contentResolver, LARGE, 0) == 1

    private fun toggleLarge() {
        try {
            Settings.Secure.putInt(contentResolver, LARGE, if (largeOn()) 0 else 1)
        } catch (e: SecurityException) {
            Toast.makeText(
                this,
                "Falta permiso. En tu PC: adb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS",
                Toast.LENGTH_LONG
            ).show()
        }
        refresh()
    }

    private fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        return s?.contains(packageName) == true
    }

    private fun refresh() {
        Prefs.applyTo(this, preview)
        for (i in rowViews.indices) {
            Prefs.applyTo(this, rowViews[i])
            val mark = if (Prefs.hasImage(this, i)) "✓" else "sin imagen"
            rowButtons[i].text = "${Prefs.states[i]}: $mark"
        }
        status.text = if (serviceOn()) "Servicio: ACTIVO" else "Servicio: desactivado (actívalo en Accesibilidad)"
        tvSize.text = "Tamaño: ${Prefs.size(this)} dp"
        btnStyle.text = "Forma (si no hay imagen): ${Prefs.styles[Prefs.style(this)]}"
        btnColor.text = "Color (si no hay imagen): ${Prefs.colors[Prefs.color(this)].first}"
        btnHot.text = "Punto de clic de la imagen: ${if (Prefs.hotCenter(this)) "Centro" else "Esquina superior izquierda"}"
        btnLarge.text = "Puntero grande del sistema: ${if (largeOn()) "SÍ" else "NO"}"
    }
}
