package com.example.cursortv

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.max
import kotlin.math.min

class CursorView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    var cx = -1000f
    var cy = -1000f
    var sizePx = 56f
    var cursorStyle = 0
    var color = Color.WHITE
    var centered = false      // true en las vistas previas de la app
    var hotCenter = false     // el punto de clic de la imagen es su centro
    var strictImage = false   // vista previa: solo dibuja la imagen de su estado
    var capPx = Float.MAX_VALUE

    var images: Array<Bitmap?> = arrayOfNulls(4)
    var imgVer = -1L
    var state = 0
        private set

    private val dst = RectF()
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }

    fun moveTo(x: Float, y: Float) {
        cx = x; cy = y; invalidate()
    }

    fun setCursorState(s: Int) {
        if (state != s) {
            state = s; invalidate()
        }
    }

    private fun arrow(x: Float, y: Float, s: Float) = Path().apply {
        moveTo(x, y)
        lineTo(x, y + s * 0.85f)
        lineTo(x + s * 0.2f, y + s * 0.65f)
        lineTo(x + s * 0.35f, y + s)
        lineTo(x + s * 0.5f, y + s * 0.93f)
        lineTo(x + s * 0.35f, y + s * 0.6f)
        lineTo(x + s * 0.62f, y + s * 0.6f)
        close()
    }

    private fun drawImage(c: Canvas, bmp: Bitmap, s: Float) {
        val k = s / max(bmp.width, bmp.height)
        val w = bmp.width * k
        val h = bmp.height * k
        val left: Float
        val top: Float
        if (centered) {
            left = width / 2f - w / 2; top = height / 2f - h / 2
        } else if (hotCenter) {
            left = cx - w / 2; top = cy - h / 2
        } else {
            left = cx; top = cy
        }
        dst.set(left, top, left + w, top + h)
        c.drawBitmap(bmp, null, dst, bmpPaint)
    }

    override fun onDraw(c: Canvas) {
        val s = min(sizePx, capPx)

        val img = images.getOrNull(state) ?: (if (strictImage) null else images.getOrNull(0))
        if (img != null) {
            drawImage(c, img, s)
            return
        }
        if (strictImage) return

        val arrowish = cursorStyle == 0 || cursorStyle == 4
        val x = if (centered) width / 2f - (if (arrowish) s * 0.3f else 0f) else cx
        val y = if (centered) height / 2f - (if (arrowish) s * 0.5f else 0f) else cy
        val outline = if (color == Color.BLACK) Color.WHITE else Color.BLACK
        val w = max(2f, s / 14f)

        fill.color = color
        line.strokeWidth = w

        when (cursorStyle) {
            0 -> {
                val p = arrow(x, y, s)
                line.color = outline
                c.drawPath(p, fill)
                c.drawPath(p, line)
            }
            1 -> {
                fill.alpha = 90
                c.drawCircle(x, y, s / 2, fill)
                line.color = color
                c.drawCircle(x, y, s / 2, line)
            }
            2 -> {
                line.color = outline; line.strokeWidth = w * 2.2f
                c.drawLine(x - s / 2, y, x + s / 2, y, line)
                c.drawLine(x, y - s / 2, x, y + s / 2, line)
                line.color = color; line.strokeWidth = w
                c.drawLine(x - s / 2, y, x + s / 2, y, line)
                c.drawLine(x, y - s / 2, x, y + s / 2, line)
            }
            3 -> {
                fill.color = outline
                c.drawCircle(x, y, s / 4 + w, fill)
                fill.color = color
                c.drawCircle(x, y, s / 4, fill)
            }
            else -> {
                line.color = color
                line.strokeWidth = w * 1.5f
                c.drawPath(arrow(x, y, s), line)
            }
        }
    }
}
