package com.example.cursortv

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.max

class CursorView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    var cx = -1000f
    var cy = -1000f
    var sizePx = 56f
    var cursorStyle = 0
    var color = Color.WHITE
    var centered = false  // true en la vista previa de la app

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }

    fun moveTo(x: Float, y: Float) {
        cx = x; cy = y; invalidate()
    }

    private fun arrow(x: Float, y: Float, s: Float) = Path().apply {
        moveTo(x, y)
        lineTo(x, y + s * 0.85f)
        lineTo(x + s * 0.2f, y + s * 0.65f)
        lineTo(x + s * 0.35f, y + s)
        lineTo(x + s * 0.5f, y + s * 0.93f)
        lineTo(x + s * 0.35f, y + s * 0.6f)
        lineTo(x + s * 0.62f, y + s * 0.6f)
        close()
    }

    override fun onDraw(c: Canvas) {
        val s = sizePx
        val arrowish = cursorStyle == 0 || cursorStyle == 4
        val x = if (centered) width / 2f - (if (arrowish) s * 0.3f else 0f) else cx
        val y = if (centered) height / 2f - (if (arrowish) s * 0.5f else 0f) else cy
        val outline = if (color == Color.BLACK) Color.WHITE else Color.BLACK
        val w = max(2f, s / 14f)

        fill.color = color
        line.strokeWidth = w

        when (cursorStyle) {
            0 -> {
                val p = arrow(x, y, s)
                line.color = outline
                c.drawPath(p, fill)
                c.drawPath(p, line)
            }
            1 -> {
                fill.alpha = 90
                c.drawCircle(x, y, s / 2, fill)
                line.color = color
                c.drawCircle(x, y, s / 2, line)
            }
            2 -> {
                line.color = outline; line.strokeWidth = w * 2.2f
                c.drawLine(x - s / 2, y, x + s / 2, y, line)
                c.drawLine(x, y - s / 2, x, y + s / 2, line)
                line.color = color; line.strokeWidth = w
                c.drawLine(x - s / 2, y, x + s / 2, y, line)
                c.drawLine(x, y - s / 2, x, y + s / 2, line)
            }
            3 -> {
                fill.color = outline
                c.drawCircle(x, y, s / 4 + w, fill)
                fill.color = color
                c.drawCircle(x, y, s / 4, fill)
            }
            else -> {
                line.color = color
                line.strokeWidth = w * 1.5f
                c.drawPath(arrow(x, y, s), line)
            }
        }
    }
}
