package com.example.cursortv

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import java.io.File
import java.io.FileOutputStream

object Prefs {
    const val MIN = 16   // dp
    const val MAX = 160  // dp

    val styles = listOf("Flecha", "Círculo", "Cruz", "Punto", "Flecha (contorno)")
    val colors = listOf(
        "Blanco" to Color.WHITE,
        "Negro" to Color.BLACK,
        "Rojo" to 0xFFE53935.toInt(),
        "Verde" to 0xFF43A047.toInt(),
        "Azul" to 0xFF1E88E5.toInt(),
        "Amarillo" to 0xFFFDD835.toInt()
    )

    // Estados del cursor que pueden tener imagen propia
    val states = listOf(
        "Apuntar (normal)",
        "Seleccionar (clic presionado)",
        "Arrastrar (mover con clic)",
        "Carga (justo tras el clic)"
    )

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun size(c: Context) = sp(c).getInt("size", 56)
    fun style(c: Context) = sp(c).getInt("style", 0)
    fun color(c: Context) = sp(c).getInt("color", 0)
    fun hotCenter(c: Context) = sp(c).getBoolean("hot", false)

    fun setSize(c: Context, v: Int) = sp(c).edit().putInt("size", v).apply()
    fun setStyle(c: Context, v: Int) = sp(c).edit().putInt("style", v).apply()
    fun setColor(c: Context, v: Int) = sp(c).edit().putInt("color", v).apply()
    fun setHotCenter(c: Context, v: Boolean) = sp(c).edit().putBoolean("hot", v).apply()

    private fun imgFile(c: Context, i: Int) = File(c.filesDir, "cursor_$i.png")
    fun hasImage(c: Context, i: Int) = imgFile(c, i).exists()

    private fun loadImage(c: Context, i: Int): Bitmap? {
        val f = imgFile(c, i)
        return if (f.exists()) BitmapFactory.decodeFile(f.path) else null
    }

    fun saveImage(c: Context, i: Int, bmp: Bitmap) {
        FileOutputStream(imgFile(c, i)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bump(c)
    }

    fun clearImage(c: Context, i: Int) {
        imgFile(c, i).delete()
        bump(c)
    }

    private fun bump(c: Context) = sp(c).edit().putLong("imgver", System.nanoTime()).apply()

    fun applyTo(c: Context, v: CursorView) {
        v.sizePx = size(c) * c.resources.displayMetrics.density
        v.cursorStyle = style(c).coerceIn(0, styles.lastIndex)
        v.color = colors[color(c).coerceIn(0, colors.lastIndex)].second
        v.hotCenter = hotCenter(c)
        val ver = sp(c).getLong("imgver", 0)
        if (ver != v.imgVer) {
            v.images = Array(states.size) { loadImage(c, it) }
            v.imgVer = ver
        }
        v.invalidate()
    }
}
