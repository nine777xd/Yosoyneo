package com.example.cursortv

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

object Prefs {
    const val MIN = 16   // dp
    const val MAX = 160  // dp

    val styles = listOf("Flecha", "Círculo", "Cruz", "Punto", "Flecha (contorno)")
    val colors = listOf(
        "Blanco" to Color.WHITE,
        "Negro" to Color.BLACK,
        "Rojo" to 0xFFE53935.toInt(),
        "Verde" to 0xFF43A047.toInt(),
        "Azul" to 0xFF1E88E5.toInt(),
        "Amarillo" to 0xFFFDD835.toInt()
    )

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun size(c: Context) = sp(c).getInt("size", 56)
    fun style(c: Context) = sp(c).getInt("style", 0)
    fun color(c: Context) = sp(c).getInt("color", 0)

    fun setSize(c: Context, v: Int) = sp(c).edit().putInt("size", v).apply()
    fun setStyle(c: Context, v: Int) = sp(c).edit().putInt("style", v).apply()
    fun setColor(c: Context, v: Int) = sp(c).edit().putInt("color", v).apply()

    fun applyTo(c: Context, v: CursorView) {
        v.sizePx = size(c) * c.resources.displayMetrics.density
        v.cursorStyle = style(c).coerceIn(0, styles.lastIndex)
        v.color = colors[color(c).coerceIn(0, colors.lastIndex)].second
        v.invalidate()
    }
}
